from django.contrib import admin
from web.models import Customers

# Register your models here.

admin.site.register(Customers)
from web.models import DemoRequest
admin.site.register(DemoRequest)