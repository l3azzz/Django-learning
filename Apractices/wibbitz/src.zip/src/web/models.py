from django.db import models

# Create your models here.

class Customers(models.Model):
    name = models.CharField(max_length=128)
    image = models.ImageField(upload_to="customer_logo")
  
    def __str__(self):
        return self.name


class DemoRequest(models.Model):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email