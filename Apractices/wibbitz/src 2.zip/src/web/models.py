from django.db import models

# Create your models here.

class Customers(models.Model):
    name = models.CharField(max_length=128)
    image = models.ImageField(upload_to="customer_logo")
  
    def __str__(self):
        return self.name


class DemoRequest(models.Model):
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
    



class Features(models.Model):
    
    image = models.ImageField(upload_to="features/image")
    icon = models.FileField(upload_to="features/icon")
    icon_background = models.CharField(max_length=128)
    title = models.CharField(max_length=128)
    description = models.TextField()
    testimonial_description = models.TextField()
    testimonial_author = models.CharField(max_length=128)
    author_designation = models.CharField(max_length=128)
    testimonial_logo = models.FileField(upload_to="features/logo")
  
    def __str__(self):
        return self.title