from django.contrib import admin
from web.models import Customers, Features ,DemoRequest



admin.site.register(Customers)
admin.site.register(Features)
admin.site.register(DemoRequest)